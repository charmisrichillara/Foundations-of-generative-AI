from presentation_generator import (
    generate_presentation_outline,
    generate_pitch_deck_summary
)

def main():
    print("=== AI-Powered Presentation Generator ===")

    topic = input("Enter presentation topic: ")
    audience = input("Enter target audience: ")
    objective = input("Enter presentation objective: ")
    slides = input("Enter number of slides: ")

    outline = generate_presentation_outline(
        topic, audience, objective, slides
    )

    summary = generate_pitch_deck_summary(topic, objective)

    print("\n--- Presentation Outline ---\n")
    for slide in outline:
        print(slide)

    print("\n--- Pitch Deck Summary ---\n")
    print(summary)

if __name__ == "__main__":
    main()
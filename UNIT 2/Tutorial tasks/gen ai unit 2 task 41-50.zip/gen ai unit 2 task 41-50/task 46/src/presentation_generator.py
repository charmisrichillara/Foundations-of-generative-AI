def generate_presentation_outline(topic, audience, objective, slides):
    return [
        f"Slide 1: Title – {topic}",
        f"Slide 2: Introduction – Overview of {topic} for {audience}",
        f"Slide 3: Problem Statement – Key challenges related to {topic}",
        f"Slide 4: Solution – How the business addresses these challenges",
        f"Slide 5: Benefits – Value proposition for {audience}",
        f"Slide 6: Business Impact – Alignment with objective: {objective}",
        f"Slide 7: Conclusion – Key takeaways and next steps"
    ][:int(slides)]


def generate_pitch_deck_summary(topic, objective):
    return (
        f"This pitch deck presents {topic} with a focus on {objective}. "
        f"It highlights the problem, solution, value proposition, and growth potential "
        f"to engage stakeholders and decision-makers."
    )
# AI-Powered Presentation Generator

This project simulates an AI-based system that generates:
- Business presentation outlines
- Pitch deck summaries

## How to Run

```bash
python src/main.py
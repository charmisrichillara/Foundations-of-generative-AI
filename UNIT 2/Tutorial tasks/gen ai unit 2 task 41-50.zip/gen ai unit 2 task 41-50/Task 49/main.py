from workflows.proposal_generator import generate_proposal
from workflows.grant_writer import generate_grant_docs

project_title = "AI-Driven Healthcare Diagnosis System"
funding_agency = "Government Research Council"
budget = "₹50 Lakhs"

proposal = generate_proposal(project_title)
grant_docs = generate_grant_docs(project_title, funding_agency, budget)

print("PROPOSAL OUTLINE:\n", proposal["outline"])
print("\nIMPACT STATEMENT:\n", proposal["impact"])
print("\nEXECUTIVE SUMMARY:\n", grant_docs["executive_summary"])
print("\nBUDGET JUSTIFICATION:\n", grant_docs["budget_justification"])
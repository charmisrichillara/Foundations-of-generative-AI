# Proposal Writing Assistant

An AI-powered assistant that automates proposal and grant writing using structured prompt templates.

## Features
- Proposal outline generation
- Executive summary creation
- Budget justification
- Impact statement automation

## How to Run
```bash
python main.py
from utils.prompt_loader import load_prompt

def generate_grant_docs(project_title, funding_agency, budget):
    summary = load_prompt("prompts/executive_summary.json")
    budget_prompt = load_prompt("prompts/budget_justification.json")

    return {
        "executive_summary": summary["template"].format(
            project_title=project_title,
            funding_agency=funding_agency
        ),
        "budget_justification": budget_prompt["template"].format(
            budget_amount=budget
        )
    }
from utils.prompt_loader import load_prompt

def generate_proposal(project_title):
    outline = load_prompt("prompts/proposal_outline.json")
    impact = load_prompt("prompts/impact_statement.json")

    outline_text = outline["template"].format(project_title=project_title)
    impact_text = impact["template"].format(project_title=project_title)

    return {
        "outline": outline_text,
        "impact": impact_text
    }
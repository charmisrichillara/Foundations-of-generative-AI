task 47

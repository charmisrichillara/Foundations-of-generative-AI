from content_pipeline import run_pipeline

def main():
    print("=== AI Content Production Workflow ===")
    topic = input("Enter content topic: ")

    result = run_pipeline(topic)

    print("\n--- Generated Content ---\n")
    print(result["generated"])

    print("\n--- Refined Content ---\n")
    print(result["refined"])

    print("\n--- Final Content ---\n")
    print(result["final"])

if __name__ == "__main__":
    main()
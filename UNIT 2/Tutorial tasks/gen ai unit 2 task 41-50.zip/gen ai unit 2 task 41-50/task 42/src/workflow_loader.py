import json
import os

def load_workflow(stage):
    base_path = os.path.join(os.path.dirname(__file__), "..", "workflows")
    file_path = os.path.join(base_path, f"{stage}.json")

    if not os.path.exists(file_path):
        return None

    with open(file_path, "r") as file:
        return json.load(file)
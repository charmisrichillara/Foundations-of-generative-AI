def run_pipeline(topic):
    # Stage 1: Content Generation (Simulated AI)
    generated_content = f"""
Artificial Intelligence (AI) in education enhances learning experiences by providing
personalized learning paths, intelligent tutoring systems, and automated assessments.
AI helps teachers save time and improves student engagement through adaptive technologies.
"""

    # Stage 2: Content Refinement
    refined_content = f"""
Artificial Intelligence (AI) significantly improves education by enabling personalized
learning, intelligent tutoring, and automated assessment systems. These technologies
reduce teacher workload and enhance student engagement.
"""

    # Stage 3: Final Content (Polished Output)
    final_content = f"""
Artificial Intelligence (AI) is transforming education by making learning more
personalized, efficient, and accessible. Through adaptive learning systems,
intelligent tutoring, and automated assessments, AI enhances student engagement
while supporting teachers in delivering high-quality education.
"""

    return {
        "generated": generated_content.strip(),
        "refined": refined_content.strip(),
        "final": final_content.strip()
    }
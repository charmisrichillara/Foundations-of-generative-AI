# AI Content Production Workflow

This project demonstrates an AI-driven workflow for automated content generation,
refinement, and proofreading.

## Workflow Stages
- Content Generation
- Refinement
- Proofreading

## Run
python src/main.py
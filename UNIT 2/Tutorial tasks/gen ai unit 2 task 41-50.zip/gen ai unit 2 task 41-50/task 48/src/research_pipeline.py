from prompt_templates import (
    research_summary_prompt,
    key_insights_prompt,
    comparison_prompt
)

def run_pipeline():
    print("\n=== AI Research Intelligence Assistant ===")
    print("1. Research Summary")
    print("2. Key Insights Extraction")
    print("3. Research Comparison")

    choice = input("Select option (1/2/3): ")

    if choice == "1":
        topic = input("Enter research topic: ")
        text = input("Paste research text: ")
        print("\n--- Generated Summary Prompt ---")
        print(research_summary_prompt(topic, text))

    elif choice == "2":
        text = input("Paste research content: ")
        print("\n--- Generated Insights Prompt ---")
        print(key_insights_prompt(text))

    elif choice == "3":
        a = input("Paste Research Source A: ")
        b = input("Paste Research Source B: ")
        print("\n--- Generated Comparison Prompt ---")
        print(comparison_prompt(a, b))

    else:
        print("Invalid option selected.")
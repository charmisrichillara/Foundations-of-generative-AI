def research_summary_prompt(topic, text):
    return f"""
Research Topic: {topic}

Summarize the following research clearly:
{text}

Include:
- Purpose
- Methodology
- Key Findings
- Conclusion
"""


def key_insights_prompt(text):
    return f"""
Extract 5 key insights from the following research content:
{text}
"""


def comparison_prompt(a, b):
    return f"""
Compare the following research sources:

Source A:
{a}

Source B:
{b}

Highlight similarities, differences, strengths, and limitations.
"""
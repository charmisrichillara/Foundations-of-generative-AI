# AI Research Intelligence Assistant

This project automates research analysis by generating structured AI prompts
for summarization, insight extraction, and comparison.

## Features
- Research paper summarization
- Key insights extraction
- Comparative research analysis

## How to Run
```bash
python src/main.py
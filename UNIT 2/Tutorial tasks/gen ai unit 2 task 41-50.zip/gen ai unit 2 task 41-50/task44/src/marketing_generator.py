def generate_campaign_idea(product, audience, goal):
    return (
        f"Launch a digital marketing campaign for {product} targeting {audience}. "
        f"The campaign focuses on {goal} using social media, email marketing, and influencer outreach."
    )


def generate_advertisement(product):
    return (
        f"Experience the power of {product}! Designed to deliver quality, "
        f"performance, and value. Try it today and see the difference."
    )


def generate_promotional_message(product, offer):
    return (
        f"Special Offer! Get {product} now with {offer}. "
        f"Limited-time deal — don’t miss out!"
    )
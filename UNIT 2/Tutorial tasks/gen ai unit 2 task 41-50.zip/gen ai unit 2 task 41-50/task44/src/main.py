from marketing_generator import (
    generate_campaign_idea,
    generate_advertisement,
    generate_promotional_message
)

def main():
    print("=== Marketing Content Generator ===")

    product = input("Enter product name: ")
    audience = input("Enter target audience: ")
    goal = input("Enter campaign goal: ")
    offer = input("Enter promotional offer: ")

    campaign = generate_campaign_idea(product, audience, goal)
    advertisement = generate_advertisement(product)
    promotion = generate_promotional_message(product, offer)

    print("\n--- Marketing Campaign Idea ---")
    print(campaign)

    print("\n--- Advertisement Copy ---")
    print(advertisement)

    print("\n--- Promotional Message ---")
    print(promotion)

if __name__ == "__main__":
    main()
# Marketing Content Generator

This project simulates an AI-driven marketing content generator that produces:
- Marketing campaign ideas
- Advertisement copy
- Promotional messages

## How to Run

```bash
python src/main.py